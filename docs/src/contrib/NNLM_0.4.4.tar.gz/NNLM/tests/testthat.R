library(testthat)
library(NNLM)

test_check("NNLM")
